

document.getElementById('order').addEventListener('click', function() {
    chrome.tabs.create({url: 'https://academicexpert.uk/order-now/'});
});
document.getElementById('dissertation').addEventListener('click', function() {
    chrome.tabs.create({url: 'https://academicexpert.uk/dissertation-writing/'});
});
document.getElementById('blog').addEventListener('click', function() {
    chrome.tabs.create({url: 'https://academicexpert.uk/academicexpert-blog/'});
});
document.getElementById('assignment').addEventListener('click', function() {
    chrome.tabs.create({url: 'https://academicexpert.uk/cheap-assignment-writing-services/'});
});
document.getElementById('inquiry').addEventListener('click', function() {
    chrome.tabs.create({url: 'https://tawk.to/chat/6475c68b74285f0ec46e6882/1h1m0v4m9'});
});
// Add similar event listeners for other buttons
